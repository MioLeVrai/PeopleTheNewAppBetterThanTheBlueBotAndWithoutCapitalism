@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"

echo ============================================================
echo   PEOPLE - BOUTON REJOINDRE POUR APPEL MP ACTIF
echo ============================================================
echo.

set "PATCH=%~dp0people-dm-join-label.patch"

if not exist "public\people-dm-calls.js" (
  echo [ERREUR] public\people-dm-calls.js introuvable.
  echo Mets ce BAT et le patch dans le dossier People, a cote de server.js.
  pause
  exit /b 1
)

if not exist "%PATCH%" (
  echo [ERREUR] people-dm-join-label.patch introuvable.
  pause
  exit /b 1
)

where git >nul 2>&1
if errorlevel 1 (
  echo [ERREUR] Git n'est pas disponible dans le PATH.
  pause
  exit /b 1
)

echo [1/4] Verification : correctif deja installe ?
git apply --reverse --check --ignore-space-change --ignore-whitespace "%PATCH%" >nul 2>&1
if not errorlevel 1 (
  echo [OK] Le bouton Rejoindre est deja installe.
  echo Aucun fichier n'a ete modifie.
  pause
  exit /b 0
)

echo [2/4] Verification de compatibilite...
git apply --check --ignore-space-change --ignore-whitespace "%PATCH%"
if errorlevel 1 (
  echo.
  echo [STOP] Ce mini-patch ne correspond pas exactement a ta version actuelle.
  echo Aucun fichier n'a ete modifie.
  pause
  exit /b 1
)

for /f %%I in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "STAMP=%%I"
if not defined STAMP set "STAMP=%RANDOM%"
set "BACKUP=backup_dm_join_button_%STAMP%"

mkdir "%BACKUP%\public" >nul 2>&1
copy /Y "public\people-dm-calls.js" "%BACKUP%\public\people-dm-calls.js" >nul
if errorlevel 1 (
  echo [ERREUR] Impossible de creer la sauvegarde.
  pause
  exit /b 1
)

echo [3/4] Application du mini-correctif...
git apply --ignore-space-change --ignore-whitespace "%PATCH%"
if errorlevel 1 (
  echo [ERREUR] Impossible d'appliquer le correctif.
  pause
  exit /b 1
)

echo [4/4] Verification JavaScript...
where node >nul 2>&1
if errorlevel 1 goto success

node --check "public\people-dm-calls.js"
if errorlevel 1 goto rollback

goto success

:rollback
echo.
echo [ERREUR] La verification JS a echoue.
echo Restauration de la sauvegarde...
copy /Y "%BACKUP%\public\people-dm-calls.js" "public\people-dm-calls.js" >nul
echo [OK] Ancienne version restauree.
pause
exit /b 1

:success
echo.
echo ============================================================
echo [OK] BOUTON REJOINDRE INSTALLE
echo ============================================================
echo.
echo - Quand une room MP existe encore et que tu peux y revenir : Rejoindre.
echo - Quand la room est fermee : Appeler.
echo - Aucun changement dans server.js.
echo.
echo Sauvegarde : %BACKUP%
pause
exit /b 0
