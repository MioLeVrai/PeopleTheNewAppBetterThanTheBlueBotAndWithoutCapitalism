@echo off
setlocal
cd /d "%~dp0"
title People - Palette RGB personnalisable

echo ============================================
echo   PEOPLE - PALETTE RGB PERSONNALISABLE
echo ============================================
echo.

if not exist "server.js" (
  echo [ERREUR] server.js introuvable.
  echo Mets tout le contenu du ZIP directement dans le dossier People,
  echo a cote de server.js, puis relance ce BAT.
  echo.
  pause
  exit /b 1
)

where node >nul 2>nul
if errorlevel 1 (
  echo [ERREUR] Node.js est introuvable dans le PATH.
  echo.
  pause
  exit /b 1
)

node "%~dp0people-palette-v2-install.js"
set "EXITCODE=%ERRORLEVEL%"

echo.
if not "%EXITCODE%"=="0" (
  echo Installation arretee. Regarde le message d'erreur ci-dessus.
) else (
  echo Termine. Redemarre People et ouvre Parametres ^> Apparence.
)
echo.
pause
exit /b %EXITCODE%
