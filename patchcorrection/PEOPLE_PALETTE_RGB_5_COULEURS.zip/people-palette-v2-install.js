"use strict";

const fs = require("fs");
const path = require("path");
const os = require("os");
const { spawnSync } = require("child_process");

const root = process.cwd();
const dataDir = path.join(root, "_people_palette_v2");

const paths = {
  server: path.join(root, "server.js"),
  settingsJs: path.join(root, "public", "people-settings.js"),
  settingsCss: path.join(root, "public", "people-settings.css"),
  appearanceJs: path.join(root, "public", "people-appearance.js")
};

const requiredPayload = {
  appearanceJs: "people-appearance.js",
  serverBlock: "server-block.txt",
  serverRoutes: "server-routes.txt",
  settingsHtml: "settings-html.txt",
  settingsDeclarations: "settings-declarations.txt",
  settingsLogic: "settings-logic.txt",
  settingsCss: "settings-css.txt"
};

function die(message) {
  console.error("\n[ERREUR] " + message + "\n");
  process.exit(1);
}

function read(file) {
  return fs.readFileSync(file, "utf8");
}

function payload(name) {
  const file = path.join(dataDir, requiredPayload[name]);
  if (!fs.existsSync(file)) {
    die("Fichier d'installation manquant : " + file);
  }
  return read(file).replace(/\s+$/, "");
}

for (const [name, file] of Object.entries(paths)) {
  if (!fs.existsSync(file)) {
    die(
      "Impossible de trouver " + path.relative(root, file) +
      ". Mets le BAT et le dossier _people_palette_v2 à côté de server.js."
    );
  }
}

if (!fs.existsSync(dataDir)) {
  die("Le dossier _people_palette_v2 est absent.");
}

const original = {
  server: read(paths.server),
  settingsJs: read(paths.settingsJs),
  settingsCss: read(paths.settingsCss),
  appearanceJs: read(paths.appearanceJs)
};

if (
  original.server.includes("PEOPLE_APPEARANCE_V2_START") &&
  original.settingsCss.includes("PEOPLE_SETTINGS_APPEARANCE_V2_START") &&
  original.appearanceJs.includes("PEOPLE_APPEARANCE_CLIENT_V2_START")
) {
  console.log("\n[OK] La palette RGB V2 est déjà installée. Rien à faire.\n");
  process.exit(0);
}

if (!original.server.includes("PEOPLE_APPEARANCE_V1_START")) {
  die("Je ne trouve pas le module d'apparence V1 dans server.js. Aucune modification n'a été faite.");
}

if (!original.server.includes("PEOPLE_APPEARANCE_ROUTES_V1_START")) {
  die("Je ne trouve pas les routes d'apparence V1 dans server.js. Aucune modification n'a été faite.");
}

if (!original.appearanceJs.includes("PEOPLE_APPEARANCE_CLIENT_V1_START")) {
  die("Je ne trouve pas people-appearance.js V1. Aucune modification n'a été faite.");
}

if (!original.settingsCss.includes("PEOPLE_SETTINGS_APPEARANCE_V1_START")) {
  die("Je ne trouve pas le bloc CSS d'apparence V1. Aucune modification n'a été faite.");
}

function replaceOne(source, regex, replacement, label) {
  const matches = source.match(regex);
  if (!matches) {
    die("Zone introuvable : " + label + ". Aucune modification n'a été écrite.");
  }
  return source.replace(regex, replacement);
}

let server = original.server;
server = replaceOne(
  server,
  /\/\/ === PEOPLE_APPEARANCE_V1_START ===[\s\S]*?\/\/ === PEOPLE_APPEARANCE_V1_END ===/,
  payload("serverBlock"),
  "logique apparence serveur"
);
server = replaceOne(
  server,
  /\/\/ === PEOPLE_APPEARANCE_ROUTES_V1_START ===[\s\S]*?\/\/ === PEOPLE_APPEARANCE_ROUTES_V1_END ===/,
  payload("serverRoutes"),
  "routes apparence serveur"
);

if (!server.includes("appearance_palette TEXT")) {
  const accentAlter = /  await peoplePool\.query\(\s*"ALTER TABLE people_accounts " \+\s*"ADD COLUMN IF NOT EXISTS appearance_accent VARCHAR\(7\) NOT NULL DEFAULT '#67589D'"\s*\);/;
  const match = server.match(accentAlter);
  if (!match) {
    die("Je ne trouve pas la migration PostgreSQL appearance_accent. Aucune modification n'a été écrite.");
  }

  const paletteAlter =
    match[0] +
    "\n\n  await peoplePool.query(\n" +
    "    \"ALTER TABLE people_accounts \" +\n" +
    "    \"ADD COLUMN IF NOT EXISTS appearance_palette TEXT NOT NULL DEFAULT ''\"\n" +
    "  );";

  server = server.replace(accentAlter, paletteAlter);
}

let settingsJs = original.settingsJs;
settingsJs = replaceOne(
  settingsJs,
  /        <section\n          class="people-settings-page"\n          data-settings-page="appearance"\n        >[\s\S]*?        <\/section>\n\n(?=        <section\n          class="people-settings-page"\n          data-settings-page="sounds")/,
  payload("settingsHtml") + "\n\n",
  "page Apparence"
);

const declarationsStart = settingsJs.indexOf("  const appearanceThemes =");
const declarationsEnd = settingsJs.indexOf("  const ringtones =", declarationsStart);
if (declarationsStart < 0 || declarationsEnd < 0) {
  die("Déclarations Apparence introuvables dans people-settings.js. Aucune modification n'a été écrite.");
}
settingsJs =
  settingsJs.slice(0, declarationsStart) +
  payload("settingsDeclarations") + "\n\n" +
  settingsJs.slice(declarationsEnd);

const logicStart = settingsJs.indexOf(
  "  // ==========================================================\n" +
  "  // APPARENCE\n" +
  "  // =========================================================="
);
const logicEnd = settingsJs.indexOf("  function activateTab(", logicStart);
if (logicStart < 0 || logicEnd < 0) {
  die("Logique Apparence introuvable dans people-settings.js. Aucune modification n'a été écrite.");
}
settingsJs =
  settingsJs.slice(0, logicStart) +
  payload("settingsLogic") +
  settingsJs.slice(logicEnd);

let settingsCss = replaceOne(
  original.settingsCss,
  /\/\* === PEOPLE_SETTINGS_APPEARANCE_V1_START === \*\/[\s\S]*?\/\* === PEOPLE_SETTINGS_APPEARANCE_V1_END === \*\//,
  payload("settingsCss"),
  "CSS Apparence"
);

const appearanceJs = payload("appearanceJs") + "\n";

function checkJs(label, content) {
  const temp = path.join(
    os.tmpdir(),
    "people_palette_" + process.pid + "_" + label.replace(/[^a-z0-9]/gi, "_") + ".js"
  );

  try {
    fs.writeFileSync(temp, content, "utf8");
    const result = spawnSync(process.execPath, ["--check", temp], {
      encoding: "utf8"
    });

    if (result.status !== 0) {
      console.error(result.stdout || "");
      console.error(result.stderr || "");
      die("Le pré-contrôle JavaScript a échoué pour " + label + ". Aucun fichier du projet n'a été modifié.");
    }
  } finally {
    try { fs.unlinkSync(temp); } catch {}
  }
}

console.log("[1/4] Pré-contrôle JavaScript...");
checkJs("server", server);
checkJs("people-settings", settingsJs);
checkJs("people-appearance", appearanceJs);
console.log("      OK");

function stamp() {
  const d = new Date();
  const two = (n) => String(n).padStart(2, "0");
  return (
    d.getFullYear() +
    two(d.getMonth() + 1) +
    two(d.getDate()) + "_" +
    two(d.getHours()) +
    two(d.getMinutes()) +
    two(d.getSeconds())
  );
}

const backupDir = path.join(root, "backup_palette_rgb_" + stamp());
console.log("[2/4] Sauvegarde dans " + path.basename(backupDir) + "...");
fs.mkdirSync(path.join(backupDir, "public"), { recursive: true });
fs.copyFileSync(paths.server, path.join(backupDir, "server.js"));
fs.copyFileSync(paths.settingsJs, path.join(backupDir, "public", "people-settings.js"));
fs.copyFileSync(paths.settingsCss, path.join(backupDir, "public", "people-settings.css"));
fs.copyFileSync(paths.appearanceJs, path.join(backupDir, "public", "people-appearance.js"));
console.log("      OK");

const writes = [
  [paths.server, server],
  [paths.settingsJs, settingsJs],
  [paths.settingsCss, settingsCss],
  [paths.appearanceJs, appearanceJs]
];

console.log("[3/4] Installation de la palette personnalisée...");
try {
  for (const [file, content] of writes) {
    fs.writeFileSync(file, content, "utf8");
  }
} catch (err) {
  console.error(err);
  console.log("Restauration de la sauvegarde...");
  try {
    fs.copyFileSync(path.join(backupDir, "server.js"), paths.server);
    fs.copyFileSync(path.join(backupDir, "public", "people-settings.js"), paths.settingsJs);
    fs.copyFileSync(path.join(backupDir, "public", "people-settings.css"), paths.settingsCss);
    fs.copyFileSync(path.join(backupDir, "public", "people-appearance.js"), paths.appearanceJs);
  } catch {}
  die("Écriture impossible. Les fichiers ont été restaurés autant que possible.");
}
console.log("      OK");

console.log("[4/4] Vérification finale...");
for (const [label, file] of [
  ["server.js", paths.server],
  ["public/people-settings.js", paths.settingsJs],
  ["public/people-appearance.js", paths.appearanceJs]
]) {
  const result = spawnSync(process.execPath, ["--check", file], {
    encoding: "utf8"
  });

  if (result.status !== 0) {
    console.error(result.stderr || result.stdout || "");
    die("Vérification finale échouée pour " + label + ". Utilise la sauvegarde " + path.basename(backupDir) + ".");
  }
}
console.log("      OK");

console.log("\n============================================");
console.log("  OK - PALETTE RGB PEOPLE INSTALLÉE");
console.log("============================================");
console.log("\n5 couleurs personnalisables :");
console.log("  - Fond principal");
console.log("  - Panneaux");
console.log("  - Fond secondaire");
console.log("  - Texte principal");
console.log("  - Accent");
console.log("\nChaque couleur possède : sélecteur + HEX + R/G/B.");
console.log("Les préréglages Sombre / Minuit / Clair / Système restent disponibles.");
console.log("Sauvegarde : " + path.basename(backupDir));
console.log("\nTu peux supprimer le BAT, ce script et le dossier _people_palette_v2 après l'installation.\n");
