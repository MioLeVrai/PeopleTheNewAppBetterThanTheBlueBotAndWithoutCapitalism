@echo off
setlocal
chcp 65001 >nul 2>&1
cd /d "%~dp0"

echo.
echo ============================================================
echo   PEOPLE - AJOUT COMPTE LOCAL THETESTBOY
echo ============================================================
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo [ERREUR] Node.js introuvable.
  pause
  exit /b 10
)

node "AJOUTER_COMPTE_LOCAL_THETESTBOY.js"
set "ERR=%ERRORLEVEL%"
echo.
if not "%ERR%"=="0" (
  echo Echec. Code : %ERR%
) else (
  echo Termine. Tu peux lancer People en local et te connecter.
)
echo.
pause
exit /b %ERR%
