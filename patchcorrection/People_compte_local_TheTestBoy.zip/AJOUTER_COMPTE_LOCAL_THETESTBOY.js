const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

let bcrypt;
try {
  bcrypt = require('bcryptjs');
} catch (err) {
  console.error('[ERREUR] bcryptjs introuvable. Lance npm install a la racine du projet puis recommence.');
  process.exit(10);
}

const root = process.cwd();
const file = path.join(root, 'people-accounts.local.json');
const username = 'TheTestBoy';
const usernameKey = 'thetestboy';
const password = 'TheTestBoy';

function nowStamp() {
  return new Date().toISOString().replace(/[:.]/g, '-');
}

(async () => {
  if (!fs.existsSync(path.join(root, 'server.js'))) {
    console.error('[ERREUR] server.js introuvable. Lance ce script depuis la racine du projet People.');
    process.exit(11);
  }

  let accounts = [];
  if (fs.existsSync(file)) {
    const raw = fs.readFileSync(file, 'utf8');
    try {
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) throw new Error('format');
      accounts = parsed;
    } catch {
      console.error('[ERREUR] people-accounts.local.json est invalide. Aucune modification effectuee.');
      process.exit(12);
    }

    const backupDir = path.join(root, '.people_patch_backup');
    fs.mkdirSync(backupDir, { recursive: true });
    const backup = path.join(backupDir, `people-accounts.local.${nowStamp()}.json`);
    fs.copyFileSync(file, backup);
    console.log(`[OK] Backup : ${backup}`);
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const existing = accounts.find((a) => String(a?.username_key || '').toLowerCase() === usernameKey);

  if (existing) {
    existing.username = username;
    existing.username_key = usernameKey;
    existing.password_hash = passwordHash;
    if (!existing.created_at) existing.created_at = new Date().toISOString();
    console.log('[OK] Le compte existait deja : mot de passe local mis a jour.');
  } else {
    accounts.push({
      id: crypto.randomUUID(),
      username,
      username_key: usernameKey,
      password_hash: passwordHash,
      created_at: new Date().toISOString(),
      appearance_theme: 'dark',
      appearance_accent: '#67589D'
    });
    console.log('[OK] Compte local ajoute.');
  }

  fs.writeFileSync(file, JSON.stringify(accounts, null, 2) + '\n', 'utf8');

  const written = JSON.parse(fs.readFileSync(file, 'utf8'));
  const check = written.find((a) => a.username_key === usernameKey);
  if (!check || !(await bcrypt.compare(password, check.password_hash))) {
    console.error('[ERREUR] Verification du compte impossible.');
    process.exit(13);
  }

  console.log('');
  console.log('Connexion locale :');
  console.log('  Pseudo : TheTestBoy');
  console.log('  Mdp    : TheTestBoy');
  console.log('');
  console.log('[OK] Verification bcrypt reussie.');
})().catch((err) => {
  console.error('[ERREUR]', err?.message || err);
  process.exit(20);
});
