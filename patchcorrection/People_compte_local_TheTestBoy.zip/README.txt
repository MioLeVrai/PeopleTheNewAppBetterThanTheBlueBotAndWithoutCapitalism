PEOPLE - COMPTE LOCAL THETESTBOY
================================

Ce petit installateur modifie UNIQUEMENT :
  people-accounts.local.json

Compte cree / mis a jour :
  Pseudo : TheTestBoy
  Mdp    : TheTestBoy

INSTALLATION
------------
1. Extraire les 3 fichiers a la racine du projet People,
   au meme niveau que server.js et package.json.
2. Lancer AJOUTER_COMPTE_LOCAL_THETESTBOY.bat
3. Lancer ensuite People en local normalement.

Le mot de passe est stocke avec bcrypt, jamais en clair dans le JSON final.
Si le compte existe deja, son id et ses autres donnees sont conserves ; seul
le pseudo normalise et le mot de passe local sont remis a jour.

Une sauvegarde du fichier de comptes est creee dans .people_patch_backup.
Ce script ne touche pas PostgreSQL / Render / la production.
