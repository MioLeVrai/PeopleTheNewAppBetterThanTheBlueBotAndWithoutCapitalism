@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul 2>&1

title People - Correctif filtre Chat V2
cd /d "%~dp0"

set "PATCH=people_filtre_chat_fix_v2.patch"
set "ASSET_SRC=assets\people-facefx\cat"
set "ASSET_DST=public\assets\people-facefx\cat"

echo.
echo ============================================================
echo   PEOPLE - CORRECTIF FILTRE CHAT V2
echo ============================================================
echo.

if not exist "public\people-camera-effects.js" (
  echo [ERREUR] public\people-camera-effects.js introuvable.
  echo Place tout le contenu du ZIP a la RACINE du projet People.
  echo.
  pause
  exit /b 10
)

if not exist "public\index.html" (
  echo [ERREUR] public\index.html introuvable.
  echo.
  pause
  exit /b 11
)

if not exist "%PATCH%" (
  echo [ERREUR] %PATCH% introuvable a cote du BAT.
  echo.
  pause
  exit /b 12
)

for %%F in (ear-left.png ear-right.png whiskers-left.png whiskers-right.png nose.png) do (
  if not exist "%ASSET_SRC%\%%F" (
    echo [ERREUR] Asset manquant : %ASSET_SRC%\%%F
    echo AUCUNE modification effectuee.
    echo.
    pause
    exit /b 13
  )
)

where git >nul 2>&1
if errorlevel 1 (
  echo [ERREUR] Git est introuvable.
  echo.
  pause
  exit /b 14
)

echo [1/6] Verification du contexte actuel...
set "CODE_ALREADY_PATCHED=0"
git apply --reverse --check --whitespace=nowarn "%PATCH%" >nul 2>&1
if not errorlevel 1 (
  set "CODE_ALREADY_PATCHED=1"
  echo [OK] Partie code deja appliquee : je vais seulement verifier/copier les assets.
) else (
  git apply --check --whitespace=nowarn "%PATCH%"
  if errorlevel 1 (
    echo.
    echo [STOP] Ta version ne correspond pas au contexte attendu.
    echo AUCUN fichier n'a ete modifie.
    echo.
    pause
    exit /b 20
  )
  echo [OK] Les blocs du filtre Chat correspondent exactement.
)

echo.
echo [2/6] Sauvegarde des fichiers touches...
for /f "usebackq delims=" %%T in (`powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"`) do set "STAMP=%%T"
set "BACKUP=.people_patch_backup\filtre_chat_fix_v2_%STAMP%"
mkdir "%BACKUP%\public" >nul 2>&1
copy /y "public\people-camera-effects.js" "%BACKUP%\public\people-camera-effects.js" >nul
copy /y "public\index.html" "%BACKUP%\public\index.html" >nul
if exist "%ASSET_DST%\*.png" (
  mkdir "%BACKUP%\assets\people-facefx\cat" >nul 2>&1
  copy /y "%ASSET_DST%\*.png" "%BACKUP%\assets\people-facefx\cat\" >nul
)
echo [OK] Backup : %BACKUP%

echo.
echo [3/6] Application du diff JavaScript...
if "%CODE_ALREADY_PATCHED%"=="0" (
  git apply --whitespace=nowarn "%PATCH%"
  if errorlevel 1 (
    echo [ERREUR] Application du diff impossible.
    echo Backup conserve : %BACKUP%
    echo.
    pause
    exit /b 21
  )
  echo [OK] Diff applique.
) else (
  echo [OK] Diff deja present.
)

echo.
echo [4/6] Installation des nouveaux dessins du filtre Chat...
if not exist "%ASSET_DST%" mkdir "%ASSET_DST%" >nul 2>&1
copy /y "%ASSET_SRC%\*.png" "%ASSET_DST%\" >nul
if errorlevel 1 goto :rollback
for %%F in (ear-left.png ear-right.png whiskers-left.png whiskers-right.png nose.png) do (
  if not exist "%ASSET_DST%\%%F" goto :rollback
)
echo [OK] 5 assets installes.

echo.
echo [5/6] Verification JavaScript...
where node >nul 2>&1
if errorlevel 1 (
  echo [AVERTISSEMENT] Node.js introuvable : controle syntaxique saute.
) else (
  node --check "public\people-camera-effects.js"
  if errorlevel 1 goto :rollback
  echo [OK] Syntaxe JavaScript valide.
)

echo.
echo [6/6] Termine.
echo.
echo Correctifs appliques :
echo   - oreilles dans le bon sens ;
echo   - moustaches gauche/droite separees dans le bon sens ;
echo   - nez conserve ;
echo   - ancien fallback de dessin retire ;
echo   - cache-busting des assets et du script d'effets.
echo.
echo Aucun changement aux autres filtres, WebRTC, MP, vocaux serveur,
echo sons, selection camera, mode Reduire, server.js ou SQL.
echo.
echo Fais Ctrl+F5 une fois apres deploiement.
echo Backup : %BACKUP%
echo.
pause
exit /b 0

:rollback
echo.
echo [ERREUR] Une verification a echoue. Restauration automatique...
copy /y "%BACKUP%\public\people-camera-effects.js" "public\people-camera-effects.js" >nul
copy /y "%BACKUP%\public\index.html" "public\index.html" >nul
if exist "%ASSET_DST%" rmdir /s /q "%ASSET_DST%"
if exist "%BACKUP%\assets\people-facefx\cat\*.png" (
  mkdir "%ASSET_DST%" >nul 2>&1
  copy /y "%BACKUP%\assets\people-facefx\cat\*.png" "%ASSET_DST%\" >nul
)
echo [OK] Fichiers restaures depuis : %BACKUP%
echo.
pause
exit /b 22
