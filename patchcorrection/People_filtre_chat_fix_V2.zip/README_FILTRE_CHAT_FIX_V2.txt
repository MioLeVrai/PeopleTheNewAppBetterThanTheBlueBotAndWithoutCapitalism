PEOPLE - CORRECTIF FILTRE CHAT V2
================================

Ce patch corrige UNIQUEMENT le filtre visage "Chat".

CORRECTIONS
-----------
- oreilles remises dans le bon sens ;
- moustaches gauche/droite corrigees dans le bon sens ;
- remplacement des 5 assets du chat ;
- retrait de l'ancien fallback du chat ;
- cache-busting des assets + du script d'effets.

INSTALLATION
------------
1. Extraire tout le contenu du ZIP a la racine du projet People.
2. Lancer : APPLIQUER_FILTRE_CHAT_FIX_V2.bat
3. Redeployer puis faire Ctrl+F5 une fois.

FICHIERS MODIFIES
-----------------
- public/people-camera-effects.js
- public/index.html
- public/assets/people-facefx/cat/ear-left.png
- public/assets/people-facefx/cat/ear-right.png
- public/assets/people-facefx/cat/whiskers-left.png
- public/assets/people-facefx/cat/whiskers-right.png
- public/assets/people-facefx/cat/nose.png

NON MODIFIE
-----------
- autres filtres camera
- appels MP / vocaux serveur
- WebRTC / signaling
- sons join/leave/mute/unmute
- selection micro / casque / camera
- mode Reduire
- server.js / SQL / base de donnees
