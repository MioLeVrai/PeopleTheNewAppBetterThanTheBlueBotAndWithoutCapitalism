@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>&1
title People - Correctif filtre Chat V8.2
cd /d "%~dp0"

echo.
echo ============================================================
echo   PEOPLE - CORRECTIF FILTRE CHAT V8.2
echo ============================================================
echo.

if not exist "PATCH_FILTRE_CHAT_V8_2.ps1" (
  echo [ERREUR] PATCH_FILTRE_CHAT_V8_2.ps1 introuvable a cote du BAT.
  echo Extrais TOUT le ZIP a la racine du projet People.
  echo.
  pause
  exit /b 12
)

where powershell >nul 2>&1
if errorlevel 1 (
  echo [ERREUR] PowerShell est introuvable.
  echo.
  pause
  exit /b 13
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0PATCH_FILTRE_CHAT_V8_2.ps1"
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
  echo Redeploie puis fais Ctrl+F5 une fois.
) else (
  echo Le patch n'a pas ete applique. Code erreur : %RC%
)
echo.
pause
exit /b %RC%
