$ErrorActionPreference = 'Stop'

$root = $PSScriptRoot
$jsPath = Join-Path $root 'public\people-camera-effects.js'
$htmlPath = Join-Path $root 'public\index.html'
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)

function Stop-Patch([string]$Message, [int]$Code = 20) {
    Write-Host ''
    Write-Host "[STOP] $Message" -ForegroundColor Red
    Write-Host 'AUCUN fichier n''a ete modifie.' -ForegroundColor Yellow
    exit $Code
}

if (-not (Test-Path -LiteralPath $jsPath)) {
    Stop-Patch 'public\people-camera-effects.js introuvable. Extrais le ZIP a la racine du projet People.' 10
}
if (-not (Test-Path -LiteralPath $htmlPath)) {
    Stop-Patch 'public\index.html introuvable.' 11
}

$oldY = 'const whiskersY = -h * 0.065;'
$newY = 'const whiskersY = -h * 0.125;'
$oldGap = 'const whiskersInnerGap = w * 0.175;'
$newGap = 'const whiskersInnerGap = w * 0.105;'
$cacheValue = 'people-camera-effects.js?v=people-cat-fix-v8-2-20260911a'
$cachePattern = 'people-camera-effects\.js\?v=[^"''<>\s]+'

Write-Host '[1/5] Verification chirurgicale...' -ForegroundColor Cyan
$js = [IO.File]::ReadAllText($jsPath)
$html = [IO.File]::ReadAllText($htmlPath)

$oldYCount = ([regex]::Matches($js, [regex]::Escape($oldY))).Count
$newYCount = ([regex]::Matches($js, [regex]::Escape($newY))).Count
$oldGapCount = ([regex]::Matches($js, [regex]::Escape($oldGap))).Count
$newGapCount = ([regex]::Matches($js, [regex]::Escape($newGap))).Count

if (($oldYCount + $newYCount) -ne 1) {
    Stop-Patch 'La ligne whiskersY n''est ni exactement en V7 ni deja en V8.1/V8.2. Je refuse de deviner.'
}
if (($oldGapCount + $newGapCount) -ne 1) {
    Stop-Patch 'La ligne whiskersInnerGap n''est ni exactement en V7 ni deja en V8.1/V8.2. Je refuse de deviner.'
}
if (-not [regex]::IsMatch($html, $cachePattern)) {
    Stop-Patch 'La balise people-camera-effects.js est introuvable dans public\index.html.'
}

$jsNeedsChange = ($oldYCount -eq 1) -or ($oldGapCount -eq 1)
$htmlNeedsChange = -not $html.Contains($cacheValue)

if (-not $jsNeedsChange -and -not $htmlNeedsChange) {
    Write-Host '[OK] V8.2 est deja appliquee. Rien a faire.' -ForegroundColor Green
    exit 0
}

if ($oldYCount -eq 1 -and $oldGapCount -eq 1) {
    Write-Host '[OK] Etat V7 detecte : les deux valeurs vont etre corrigees.' -ForegroundColor Green
} elseif ($newYCount -eq 1 -and $newGapCount -eq 1) {
    Write-Host '[OK] Les moustaches ont deja ete modifiees par le V8.1 avant son erreur ; je termine proprement.' -ForegroundColor Green
} else {
    Write-Host '[OK] Etat partiellement modifie detecte ; seules les valeurs encore en V7 seront corrigees.' -ForegroundColor Green
}

Write-Host '[2/5] Sauvegarde...' -ForegroundColor Cyan
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backupRoot = Join-Path $root ".people_patch_backup\filtre_chat_fix_v8_2_$stamp"
$backupPublic = Join-Path $backupRoot 'public'
New-Item -ItemType Directory -Path $backupPublic -Force | Out-Null
Copy-Item -LiteralPath $jsPath -Destination (Join-Path $backupPublic 'people-camera-effects.js') -Force
Copy-Item -LiteralPath $htmlPath -Destination (Join-Path $backupPublic 'index.html') -Force
Write-Host "[OK] Backup : $backupRoot" -ForegroundColor Green

try {
    Write-Host '[3/5] Modification...' -ForegroundColor Cyan
    $patchedJs = $js.Replace($oldY, $newY).Replace($oldGap, $newGap)
    $patchedHtml = [regex]::Replace($html, $cachePattern, $cacheValue, 1)

    [IO.File]::WriteAllText($jsPath, $patchedJs, $utf8NoBom)
    [IO.File]::WriteAllText($htmlPath, $patchedHtml, $utf8NoBom)

    Write-Host '[4/5] Verification...' -ForegroundColor Cyan
    $verifyJs = [IO.File]::ReadAllText($jsPath)
    $verifyHtml = [IO.File]::ReadAllText($htmlPath)

    if (([regex]::Matches($verifyJs, [regex]::Escape($newY))).Count -ne 1) {
        throw 'whiskersY cible absent ou duplique.'
    }
    if (([regex]::Matches($verifyJs, [regex]::Escape($newGap))).Count -ne 1) {
        throw 'whiskersInnerGap cible absent ou duplique.'
    }
    if (-not $verifyHtml.Contains($cacheValue)) {
        throw 'cache-busting non applique dans index.html.'
    }

    $node = Get-Command node -ErrorAction SilentlyContinue
    if ($null -ne $node) {
        & $node.Source '--check' $jsPath
        if ($LASTEXITCODE -ne 0) {
            throw "node --check a echoue avec le code $LASTEXITCODE."
        }
        Write-Host '[OK] Syntaxe JavaScript valide.' -ForegroundColor Green
    } else {
        Write-Host '[AVERTISSEMENT] Node.js introuvable : controle syntaxique saute.' -ForegroundColor Yellow
    }

    Write-Host '[5/5] Termine.' -ForegroundColor Cyan
    Write-Host '[OK] Moustaches montees et rapprochees. Oreilles et nez inchanges.' -ForegroundColor Green
    Write-Host "Backup : $backupRoot"
    exit 0
}
catch {
    Write-Host ''
    Write-Host "[ERREUR] $($_.Exception.Message)" -ForegroundColor Red
    Write-Host 'Restauration automatique...' -ForegroundColor Yellow
    Copy-Item -LiteralPath (Join-Path $backupPublic 'people-camera-effects.js') -Destination $jsPath -Force
    Copy-Item -LiteralPath (Join-Path $backupPublic 'index.html') -Destination $htmlPath -Force
    Write-Host "[OK] Restaure depuis : $backupRoot" -ForegroundColor Green
    exit 22
}
