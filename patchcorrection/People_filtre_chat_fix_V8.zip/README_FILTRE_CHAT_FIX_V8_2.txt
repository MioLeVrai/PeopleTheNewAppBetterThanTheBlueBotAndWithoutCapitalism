PEOPLE - CORRECTIF FILTRE CHAT V8.2
==================================

Pourquoi V8.2 ?
----------------
Le BAT V8.1 contenait une commande PowerShell en ligne avec des caracteres ^.
Selon la facon dont Windows l'interpretait, PowerShell pouvait essayer d'executer
^ comme une commande. V8.2 supprime completement ce probleme : le BAT appelle un
fichier PowerShell separe.

Le patch accepte trois etats :
- V7 normal ;
- V8.1 ayant deja modifie les moustaches avant de planter ;
- etat partiel ou une seule des deux valeurs a ete modifiee.

Modifications fonctionnelles :
- moustaches remontees ;
- moustaches rapprochees l'une de l'autre ;
- oreilles et nez inchanges ;
- mise a jour du cache de people-camera-effects.js.

INSTALLATION
------------
1. Extraire LES 3 fichiers du ZIP a la racine du projet People.
2. Lancer APPLIQUER_FILTRE_CHAT_FIX_V8_2.bat.
3. Redeployer puis faire Ctrl+F5 une fois.

Le script cree une sauvegarde dans .people_patch_backup avant toute ecriture et
restaure automatiquement les fichiers si une verification echoue.
