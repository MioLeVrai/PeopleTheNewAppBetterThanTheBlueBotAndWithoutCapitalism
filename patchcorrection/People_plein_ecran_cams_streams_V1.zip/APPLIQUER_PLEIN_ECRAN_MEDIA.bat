@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title People - Plein ecran cams et streams

echo.
echo ============================================================
echo   PEOPLE - PLEIN ECRAN CAMS / STREAMS + CADRE MP FIXE
echo ============================================================
echo.

if not exist "public\index.html" (
  echo [ERREUR] public\index.html introuvable.
  echo Extrais TOUT le ZIP a la racine du projet People.
  echo.
  pause
  exit /b 10
)

if not exist "APPLIQUER_PLEIN_ECRAN_MEDIA.ps1" (
  echo [ERREUR] Le script PowerShell est manquant.
  echo Re-extrais tout le ZIP.
  echo.
  pause
  exit /b 11
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLIQUER_PLEIN_ECRAN_MEDIA.ps1" -Root "%CD%"
set "RC=%ERRORLEVEL%"

echo.
if not "%RC%"=="0" (
  echo Le patch n'a pas ete installe. Le projet a ete restaure.
) else (
  echo Termine. Redeploie puis fais Ctrl+F5 une fois.
)
echo.
pause
exit /b %RC%
