param(
  [string]$Root = (Get-Location).Path
)

$ErrorActionPreference = 'Stop'

function Write-Utf8NoBom([string]$Path, [string]$Content) {
  $utf8 = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($Path, $Content, $utf8)
}

$Root = [System.IO.Path]::GetFullPath($Root)
$Public = Join-Path $Root 'public'
$Index = Join-Path $Public 'index.html'
$SourceDir = Join-Path $PSScriptRoot 'payload\public'
$SourceJs = Join-Path $SourceDir 'people-media-fullscreen.js'
$SourceCss = Join-Path $SourceDir 'people-media-fullscreen.css'
$DestJs = Join-Path $Public 'people-media-fullscreen.js'
$DestCss = Join-Path $Public 'people-media-fullscreen.css'

if (-not (Test-Path $Index)) {
  throw "public\index.html introuvable. Place le patch a la racine du projet People."
}
if (-not (Test-Path $SourceJs) -or -not (Test-Path $SourceCss)) {
  throw "Payload du patch incomplet. Re-extrais tout le ZIP."
}

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backup = Join-Path $Root ".people_patch_backup\plein_ecran_media_$stamp"
$backupPublic = Join-Path $backup 'public'
New-Item -ItemType Directory -Force -Path $backupPublic | Out-Null

Copy-Item $Index (Join-Path $backupPublic 'index.html') -Force
$hadJs = Test-Path $DestJs
$hadCss = Test-Path $DestCss
if ($hadJs) { Copy-Item $DestJs (Join-Path $backupPublic 'people-media-fullscreen.js') -Force }
if ($hadCss) { Copy-Item $DestCss (Join-Path $backupPublic 'people-media-fullscreen.css') -Force }

try {
  Write-Host '[1/5] Backup cree :' $backup -ForegroundColor Green

  Copy-Item $SourceJs $DestJs -Force
  Copy-Item $SourceCss $DestCss -Force
  Write-Host '[2/5] Module plein ecran copie.' -ForegroundColor Green

  $html = [System.IO.File]::ReadAllText($Index)

  $cssTag = '  <link rel="stylesheet" href="people-media-fullscreen.css?v=people-media-fullscreen-v1-20260911a">'
  $jsTag = '  <script src="people-media-fullscreen.js?v=people-media-fullscreen-v1-20260911a"></script>'

  $cssPattern = '(?im)^\s*<link\b[^>]*href=["''][^"'']*people-media-fullscreen\.css[^"'']*["''][^>]*>\s*$'
  if ([regex]::IsMatch($html, $cssPattern)) {
    $html = [regex]::Replace($html, $cssPattern, $cssTag, 1)
  } else {
    if ($html -notmatch '(?i)</head>') { throw '</head> introuvable dans public\index.html' }
    $html = [regex]::Replace($html, '(?i)</head>', "$cssTag`r`n</head>", 1)
  }

  $jsPattern = '(?im)^\s*<script\b[^>]*src=["''][^"'']*people-media-fullscreen\.js[^"'']*["''][^>]*>\s*</script>\s*$'
  if ([regex]::IsMatch($html, $jsPattern)) {
    $html = [regex]::Replace($html, $jsPattern, $jsTag, 1)
  } else {
    if ($html -notmatch '(?i)</body>') { throw '</body> introuvable dans public\index.html' }
    $html = [regex]::Replace($html, '(?i)</body>', "$jsTag`r`n</body>", 1)
  }

  Write-Utf8NoBom $Index $html
  Write-Host '[3/5] index.html mis a jour sans remplacer les autres scripts.' -ForegroundColor Green

  $node = Get-Command node -ErrorAction SilentlyContinue
  if ($node) {
    & $node.Source --check $DestJs
    if ($LASTEXITCODE -ne 0) { throw 'node --check a detecte une erreur JavaScript.' }
    Write-Host '[4/5] Syntaxe JavaScript valide.' -ForegroundColor Green
  } else {
    Write-Host '[4/5] Node.js introuvable : verification JS ignoree.' -ForegroundColor Yellow
  }

  $final = [System.IO.File]::ReadAllText($Index)
  if ($final -notmatch 'people-media-fullscreen\.css\?v=people-media-fullscreen-v1-20260911a') {
    throw 'La feuille CSS n est pas referencee dans index.html.'
  }
  if ($final -notmatch 'people-media-fullscreen\.js\?v=people-media-fullscreen-v1-20260911a') {
    throw 'Le script JS n est pas reference dans index.html.'
  }

  Write-Host '[5/5] Installation terminee.' -ForegroundColor Green
  Write-Host ''
  Write-Host 'Ajoute :' -ForegroundColor Cyan
  Write-Host ' - plein ecran sur cams/streams serveur'
  Write-Host ' - plein ecran sur cam/stream principal en MP'
  Write-Host ' - plein ecran depuis la fenetre Reduire'
  Write-Host ' - double-clic sur une video pour le plein ecran'
  Write-Host ' - largeur du panneau MP liee a sa hauteur reglee'
  Write-Host ' - camera distante en contain : plus de crop quand la fenetre s elargit'
  Write-Host ''
  Write-Host 'Backup :' $backup -ForegroundColor DarkGray
  exit 0
}
catch {
  Write-Host ''
  Write-Host '[ERREUR] Installation echouee :' $_.Exception.Message -ForegroundColor Red
  Write-Host 'Restauration automatique...' -ForegroundColor Yellow

  Copy-Item (Join-Path $backupPublic 'index.html') $Index -Force

  if ($hadJs) {
    Copy-Item (Join-Path $backupPublic 'people-media-fullscreen.js') $DestJs -Force
  } elseif (Test-Path $DestJs) {
    Remove-Item $DestJs -Force
  }

  if ($hadCss) {
    Copy-Item (Join-Path $backupPublic 'people-media-fullscreen.css') $DestCss -Force
  } elseif (Test-Path $DestCss) {
    Remove-Item $DestCss -Force
  }

  Write-Host '[OK] Projet restaure.' -ForegroundColor Green
  exit 1
}
