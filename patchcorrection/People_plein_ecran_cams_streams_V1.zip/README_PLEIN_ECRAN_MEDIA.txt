PEOPLE - PLEIN ECRAN CAMS / STREAMS V1
======================================

OBJECTIF
--------
1. Pouvoir mettre les cameras et partages d'ecran en plein ecran.
2. En MP, empecher le panneau video de devenir immense quand la fenetre People
   est elargie ou mise en plein ecran.
3. Garder la largeur du panneau MP dependante de la hauteur deja choisie avec
   la poignee verticale de l'appel.
4. Afficher toute la camera distante sans crop (object-fit: contain).

COMPATIBILITE
-------------
- appels MP : OUI
- fenetre "Reduire" : OUI
- vocaux serveur : OUI
- cameras : OUI
- partages d'ecran / streams : OUI

UTILISATION
-----------
- bouton ⛶ sur le media ;
- ou double-clic sur une video ;
- Echap pour quitter le plein ecran.

INSTALLATION
------------
1. Extraire TOUT le ZIP a la racine du projet People, au niveau de public/.
2. Lancer APPLIQUER_PLEIN_ECRAN_MEDIA.bat
3. Redeployer.
4. Faire Ctrl+F5 une fois.

METHODE CHIRURGICALE
--------------------
Le patch ne reecrit pas app.js ni people-dm-calls.js.
Il ajoute seulement :
- public/people-media-fullscreen.js
- public/people-media-fullscreen.css

Et il ajoute 2 references dans public/index.html.
Un backup horodate est cree dans .people_patch_backup/.

AUCUN CHANGEMENT
----------------
- server.js / SQL
- WebRTC / signaling
- sons d'appel
- filtres visage
- selection camera / micro / casque
- messages / amis / serveurs
