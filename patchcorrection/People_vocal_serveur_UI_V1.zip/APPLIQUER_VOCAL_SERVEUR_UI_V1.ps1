param(
  [string]$Root = (Get-Location).Path
)

$ErrorActionPreference = 'Stop'

function Write-Utf8NoBom([string]$Path, [string]$Content) {
  $utf8 = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($Path, $Content, $utf8)
}

$Root = [System.IO.Path]::GetFullPath($Root)
$Public = Join-Path $Root 'public'
$Index = Join-Path $Public 'index.html'
$LocalControls = Join-Path $Public 'people-local-controls.js'
$SourceDir = Join-Path $PSScriptRoot 'payload\public'
$SourceJs = Join-Path $SourceDir 'people-server-voice-ui.js'
$SourceCss = Join-Path $SourceDir 'people-server-voice-ui.css'
$DestJs = Join-Path $Public 'people-server-voice-ui.js'
$DestCss = Join-Path $Public 'people-server-voice-ui.css'

foreach ($path in @($Index, $LocalControls, $SourceJs, $SourceCss)) {
  if (-not (Test-Path $path)) {
    throw "Fichier requis introuvable : $path"
  }
}

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backup = Join-Path $Root ".people_patch_backup\vocal_serveur_ui_v1_$stamp"
$backupPublic = Join-Path $backup 'public'
New-Item -ItemType Directory -Force -Path $backupPublic | Out-Null

Copy-Item $Index (Join-Path $backupPublic 'index.html') -Force
Copy-Item $LocalControls (Join-Path $backupPublic 'people-local-controls.js') -Force
$hadJs = Test-Path $DestJs
$hadCss = Test-Path $DestCss
if ($hadJs) { Copy-Item $DestJs (Join-Path $backupPublic 'people-server-voice-ui.js') -Force }
if ($hadCss) { Copy-Item $DestCss (Join-Path $backupPublic 'people-server-voice-ui.css') -Force }

try {
  Write-Host '[1/6] Backup cree :' $backup -ForegroundColor Green

  Copy-Item $SourceJs $DestJs -Force
  Copy-Item $SourceCss $DestCss -Force
  Write-Host '[2/6] Module d interface vocal serveur copie.' -ForegroundColor Green

  $local = [System.IO.File]::ReadAllText($LocalControls)
  $marker = 'PEOPLE_LOCAL_AUDIO_VOICE_PAYLOAD_V2'

  if ($local -notmatch [regex]::Escape($marker)) {
    $pattern = 'peopleSocket\.on\(\s*["'']voice-state["'']\s*,\s*scheduleRosterRender\s*\);'
    if (-not [regex]::IsMatch($local, $pattern)) {
      throw 'Impossible de trouver le branchement voice-state dans people-local-controls.js. Aucune modification forcee.'
    }

    $replacement = @'
// === PEOPLE_LOCAL_AUDIO_VOICE_PAYLOAD_V2 ===
function peopleLocalAudioRosterFromVoiceState(payload) {
  if (Array.isArray(payload)) return payload;
  return Array.isArray(payload?.roster) ? payload.roster : [];
}

peopleSocket.on("voice-state", (payload) => {
  scheduleRosterRender(peopleLocalAudioRosterFromVoiceState(payload));
});
// === PEOPLE_LOCAL_AUDIO_VOICE_PAYLOAD_V2_END ===
'@

    $local = [regex]::Replace($local, $pattern, [System.Text.RegularExpressions.MatchEvaluator]{ param($m) $replacement }, 1)
    Write-Utf8NoBom $LocalControls $local
    Write-Host '[3/6] Volume individuel repare pour le nouveau payload voice-state.' -ForegroundColor Green
  } else {
    Write-Host '[3/6] Correctif volume individuel deja present.' -ForegroundColor DarkGray
  }

  $html = [System.IO.File]::ReadAllText($Index)

  $cssTag = '  <link rel="stylesheet" href="people-server-voice-ui.css?v=people-server-voice-ui-v1-20260911a">'
  $jsTag = '  <script src="people-server-voice-ui.js?v=people-server-voice-ui-v1-20260911a"></script>'
  $localControlsTag = '  <script src="people-local-controls.js?v=people-server-voice-ui-v1-20260911a"></script>'

  $localPattern = '(?im)^\s*<script\b[^>]*src=["''][^"'']*people-local-controls\.js(?:\?[^"'']*)?["''][^>]*>\s*</script>\s*$'
  if ([regex]::IsMatch($html, $localPattern)) {
    $html = [regex]::Replace($html, $localPattern, $localControlsTag, 1)
  } else {
    if ($html -notmatch '(?i)</body>') { throw '</body> introuvable dans index.html.' }
    $html = [regex]::Replace($html, '(?i)</body>', "$localControlsTag`r`n</body>", 1)
  }

  $cssPattern = '(?im)^\s*<link\b[^>]*href=["''][^"'']*people-server-voice-ui\.css(?:\?[^"'']*)?["''][^>]*>\s*$'
  if ([regex]::IsMatch($html, $cssPattern)) {
    $html = [regex]::Replace($html, $cssPattern, $cssTag, 1)
  } else {
    if ($html -notmatch '(?i)</head>') { throw '</head> introuvable dans index.html.' }
    $html = [regex]::Replace($html, '(?i)</head>', "$cssTag`r`n</head>", 1)
  }

  $jsPattern = '(?im)^\s*<script\b[^>]*src=["''][^"'']*people-server-voice-ui\.js(?:\?[^"'']*)?["''][^>]*>\s*</script>\s*$'
  if ([regex]::IsMatch($html, $jsPattern)) {
    $html = [regex]::Replace($html, $jsPattern, $jsTag, 1)
  } else {
    if ($html -notmatch '(?i)</body>') { throw '</body> introuvable dans index.html.' }
    $html = [regex]::Replace($html, '(?i)</body>', "$jsTag`r`n</body>", 1)
  }

  Write-Utf8NoBom $Index $html
  Write-Host '[4/6] index.html mis a jour avec cache-busting.' -ForegroundColor Green

  $node = Get-Command node -ErrorAction SilentlyContinue
  if ($node) {
    & $node.Source --check $LocalControls
    if ($LASTEXITCODE -ne 0) { throw 'Erreur JavaScript dans people-local-controls.js.' }
    & $node.Source --check $DestJs
    if ($LASTEXITCODE -ne 0) { throw 'Erreur JavaScript dans people-server-voice-ui.js.' }
    Write-Host '[5/6] Syntaxe JavaScript valide.' -ForegroundColor Green
  } else {
    Write-Host '[5/6] Node.js introuvable : verification JS ignoree.' -ForegroundColor Yellow
  }

  $final = [System.IO.File]::ReadAllText($Index)
  foreach ($needle in @('people-server-voice-ui.css?v=people-server-voice-ui-v1-20260911a', 'people-server-voice-ui.js?v=people-server-voice-ui-v1-20260911a', 'people-local-controls.js?v=people-server-voice-ui-v1-20260911a')) {
    if ($final -notmatch [regex]::Escape($needle)) { throw "Reference manquante dans index.html : $needle" }
  }

  Write-Host '[6/6] Installation terminee.' -ForegroundColor Green
  Write-Host ''
  Write-Host 'Ajoute / corrige :' -ForegroundColor Cyan
  Write-Host ' - volume individuel de chaque autre membre du vocal'
  Write-Host ' - interface video serveur en carte d appel'
  Write-Host ' - barre Micro / Camera / Ecran / Raccrocher sous les cams'
  Write-Host ' - bouton effets a gauche et plein ecran a droite sur ta cam'
  Write-Host ''
  Write-Host 'Aucun changement WebRTC, signaling, server.js ou SQL.'
  Write-Host 'Backup :' $backup -ForegroundColor DarkGray
  exit 0
}
catch {
  Write-Host ''
  Write-Host '[ERREUR] Installation echouee :' $_.Exception.Message -ForegroundColor Red
  Write-Host 'Restauration automatique...' -ForegroundColor Yellow

  Copy-Item (Join-Path $backupPublic 'index.html') $Index -Force
  Copy-Item (Join-Path $backupPublic 'people-local-controls.js') $LocalControls -Force

  if ($hadJs) {
    Copy-Item (Join-Path $backupPublic 'people-server-voice-ui.js') $DestJs -Force
  } elseif (Test-Path $DestJs) {
    Remove-Item $DestJs -Force
  }

  if ($hadCss) {
    Copy-Item (Join-Path $backupPublic 'people-server-voice-ui.css') $DestCss -Force
  } elseif (Test-Path $DestCss) {
    Remove-Item $DestCss -Force
  }

  Write-Host '[OK] Projet restaure.' -ForegroundColor Green
  exit 1
}
