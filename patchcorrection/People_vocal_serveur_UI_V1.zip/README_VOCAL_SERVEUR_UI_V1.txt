PEOPLE - VOCAL SERVEUR UI V1
============================

OBJECTIF
--------
- restaurer le volume individuel pour chaque autre membre du vocal serveur ;
- rendre la zone camera/stream serveur plus proche visuellement d'un appel MP ;
- ajouter Micro / Camera / Ecran / Raccrocher directement sous les medias ;
- inverser les boutons sur la camera locale : effets a gauche, plein ecran a droite.

CAUSE DU BUG DE VOLUME
----------------------
people-local-controls.js ecoutait encore l'ancien voice-state sous forme de tableau.
Le vocal multi-serveurs envoie maintenant un objet avec payload.roster.
Le patch rend le module compatible avec les deux formats.

INSTALLATION
------------
1. Extraire TOUT le ZIP a la racine du projet People.
2. Lancer APPLIQUER_VOCAL_SERVEUR_UI_V1.bat
3. Redeployer.
4. Faire Ctrl+F5 une fois.

FICHIERS
--------
Ajoutes :
- public/people-server-voice-ui.js
- public/people-server-voice-ui.css

Modifies chirurgicalement :
- public/people-local-controls.js
- public/index.html

NON MODIFIE
-----------
- app.js
- WebRTC / signaling
- server.js / SQL
- appels MP
- filtres visage eux-memes
- sons d'appel
- selection camera / micro / casque
